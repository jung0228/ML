#include "kvs.h"
#include <dlfcn.h>

int main()
{
	void *handle;
	kvs_t* (*open)();
	int (*close)(kvs_t* kvs);
       	int (*put)(kvs_t* kvs, const char* key, const char* value);
	char* (*get)(kvs_t* kvs, const char* key);
	int (*seek)(kvs_t* kvs); 

	// 1. create KVS
	handle = dlopen("./libkvs.so", RTLD_LAZY);
	if (!handle) {
		fprintf(stderr, "%s\n", dlerror());
		exit(1);
	}

	open = dlsym(handle, "open");
	kvs_t* kvs = open("student.dat");

	if(!kvs) {
		printf("Failed to open kvs\n");
		return -1;
	} 

#if 1
	// 1) file read
	printf("Put operation...\n");

	char * rvalue;

	FILE *inputFile = fopen("student.dat", "r");

	put = dlsym(handle, "put");
	// 2) put data
	if(inputFile != NULL) {
		char buffer[100];
		while(!feof(inputFile)) {
			fgets(buffer, sizeof(buffer), inputFile);
			char *key = strtok(buffer, " ");
			char *value = strtok(NULL, " ");
			if (value == NULL) break;
			if (put(kvs, key, value) < 0){
				printf("Failed to put data\n");
				exit(-1);
			}
		}
		fclose(inputFile);	
	}
	printf("\n");	
#endif

#if 1
	// 3. get for test 
	//
	// 1) file read 
	// 2) get & compare return value with original vallue 
	printf("Get operation ...\n");
	inputFile = fopen("student.dat", "r");

	get = dlsym(handle, "get");

	if(inputFile != NULL) {
		char buffer[100];
		while(!feof(inputFile)) {
			fgets(buffer, sizeof(buffer), inputFile);
			char *key = strtok(buffer, " ");
			char *value = strtok(NULL, " ");
			if(!(rvalue = get(kvs, key))){
				printf("Failed to get data\n");
				exit(-1);
			}
			if(value==NULL) break;
			printf("get: %s, %s\n", key, rvalue);		
		}
		fclose(inputFile);
	}
#endif

	// 4. print all items 
#if 1

	seek = dlsym(handle, "seek");

	printf("\nSeek operation ...\n");
	seek(kvs);
	
#endif

#if 1

	close = dlsym(handle, "close");

	// 5. close 
	close(kvs);
#endif

	if (dlclose(handle) < 0) {
		fprintf(stderr, "%s\n", dlerror());
		exit(1);
	}
	
	return 0;
}
