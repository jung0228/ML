#include "kvs.h"

char* get(kvs_t* kvs, const char* key)
{
	/* do program here */

	char* value = (char*)malloc(sizeof(char)*100);
	
	if(!value){
		printf("Failed to malloc\n");
		return NULL;
	}

	node_t* next_p = kvs->db;
	while(next_p) {
		if(strcmp(next_p->key, key) == 0) {
				strcpy(value, next_p->value);
				break;
		}
		next_p = next_p->next;
	}
	
	return value;

}
