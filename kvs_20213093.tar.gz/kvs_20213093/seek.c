#include "kvs.h"

int seek(kvs_t* kvs)
{
	int count = 0;
	node_t* next_p;
	node_t* new_node;
	node_t* prev_p;
	node_t* list_head = NULL;
	node_t* prev_node = kvs->db;
	char temp_key[100];
	char temp_value[100];

	while(count < kvs->items) {
		strcpy(temp_key, prev_node->key);
		strcpy(temp_value, prev_node->value);
		prev_node = prev_node->next;
		new_node = (node_t*)malloc(sizeof(node_t));
		strcpy(new_node->key, temp_key);
		strcpy(new_node->value, temp_value);

		next_p = list_head;
		prev_p = NULL;
		while(next_p) {
			if(strcmp(next_p->key, new_node->key) > 0)
		      		break;
			prev_p = next_p;
			next_p = next_p->next;
		}
		new_node->next = next_p;

		if (prev_p) {
			prev_p->next=new_node;
		}else {
			list_head = new_node;
		}
		count ++;
	}
	while(list_head != NULL) {
		printf("(%s, %s)\n", list_head->key, list_head->value);
		list_head = list_head->next;
	}
	printf("\n");

	return kvs->items;
}
