#include "kvs.h"

int close(kvs_t* kvs)
{
	/* do program */
	node_t* tmp = kvs->db;
       	node_t* prev = NULL;
	for(int i=0; i<kvs->items; i++)
	{
		prev = tmp;
		tmp = tmp->next;
		free(prev);	
	}	
	return 0;
}
