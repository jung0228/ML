#include "kvs.h"

int put(kvs_t* kvs, const char* key, const char* value)
{
	printf("put: %s, %s", key, value);
	
	/* do program here */
	// make node
	node_t* new_node;
	new_node = (node_t*)malloc(sizeof(node_t));
	strcpy(new_node->key, key);
	strncpy(new_node->value, value, 2);
	new_node->next = NULL;
	
	// link node
	new_node->next = kvs->db;
	kvs->db = new_node;
	kvs->items += 1;	
	return 0;
}
